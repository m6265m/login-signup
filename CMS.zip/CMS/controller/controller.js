
const config = require('../config/configrole.js');
const db =require('../models');
require('../router/router.js')
const User=db.User;
const Role=db.Roles;
const Complain=db.Complain;
const Location=db.Location;
const ComplaintTypes=db.ComplaintTypes;
const Op = db.Sequelize.Op;

var jwt = require('jsonwebtoken');
var bcrypt = require('bcryptjs');

exports.signup = (req, res) => {
  // Save User to Database

  console.log("Processing func -> SignUp");
  User.create({
    name: req.body.name,
    email: req.body.email,
    cnic:bcrypt.hashSync(req.body.cnic, 10),
    phoneNumber:bcrypt.hashSync(req.body.phoneNumber, 10)
   // password: bcrypt.hashSync(req.body.password, 8)
  }).then(user => {
     
    Role.findAll({
      where: {
      name: {
        [Op.or]: req.body.roles
      }
    }
    }).then(roles => {
      user.setRoles(roles).then(() => {
        res.send("User registered successfully!");
            });
    })
    .catch(err => {
      res.status(500).send("Error -> " + err);
    });
  })
  .catch(err => {
    res.status(500).send("Fail! Error -> " + err);
  })
}

exports.signin = (req, res) => {
  User.findAll(
  {
    attributes:['id','phoneNumber']
  }).then(user => {

 var checkPhoneNumber=0;
  for(var i=0;i<user.length;i++){
   
     checkPhoneNumber = bcrypt.compareSync(req.body.phoneNumber, user[i].phoneNumber);
    if(checkPhoneNumber){
      var token = jwt.sign({ id: user[i].id }, config.secret, {
           expiresIn: 86400 // expires in 24 hours
         });
         console.log('access-token: '+ token);
         return res.status(200).send({ auth: true,  reason: "User already exists!"});
         
     }
}

if(checkPhoneNumber==0){
  
res.status(401).send({ auth: false, reason: "User dosenot exist!" });
 }
  })
  .catch(err => {
    res.status(500).send('Error -> ' + err);
  });
}

exports.userContent = (req, res) => {
  User.findOne({
    where: {id: req.userId},
    attributes: ['name', 'cnic', 'email','phonenumber'],
    include: [{
      model: Role,
      attributes: ['id', 'name'],
      through: {
        attributes: ['userId', 'roleId'],
      }
    }]
  }).then(user => {
    res.status(200).json({
      "description": "User Content Page",
      "user": user
    });
  }).catch(err => {
    res.status(500).json({
      "description": "Can not access User Page",
      "error": err
    });
  })
}

