module.exports = {
    'secret': 'final-year-project-secret-key',
    ROLEs: ['USER', 'ADMIN']
  };