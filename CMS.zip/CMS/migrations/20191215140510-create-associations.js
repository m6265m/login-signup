'use strict';
module.exports = {
  up: (queryInterface, Sequelize) => {
   
    return queryInterface.createTable(
      'user_roles',
      {
        createdAt: {
          allowNull: false,
          type: Sequelize.DATE,
        },
        updatedAt: {
          allowNull: false,
          type: Sequelize.DATE,
        },
      })
      .then(() => {
      return queryInterface.addColumn(
        'user_roles', // name of Target model
        'roleId', // name of the key we're adding
        {
          type: Sequelize.INTEGER,
          references: {
            model: 'Roles', // name of Source model
            key: 'id',
          },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL',
        });
      })
      .then(() => {
      return queryInterface.addColumn(
        'user_roles', // name of Target model
        'userId', // name of the key we're adding
        {
          type: Sequelize.INTEGER,
          references: {
            model: 'User', // name of Source model
            key: 'id',
          },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL',
        });
      })
      .then(() => {
      // user has many compalints
      return queryInterface.addColumn(
        'Complain', // name of Target model
        'userId', // name of the key we're adding
        {
          type: Sequelize.INTEGER,
          references: {
            model: 'User', // name of Source model
            key: 'id',
          },
          onUpdate: 'CASCADE',
          onDelete: 'SET NULL',
        });
       })
      .then(()=>{
       // complain belongs to location
       return queryInterface.addColumn(
        'Complain', // name of Source model
          'locationId', // name of the key we're adding 
          {
            type: Sequelize.INTEGER,
            references: {
              model: 'Location', // name of Target model
               key: 'id', // key in Target model that we're referencing
            }
          }
        );
      })
     .then(()=>{
      // complain belongs to complainttype
      return queryInterface.addColumn(
       'Complain', // name of Source model
         'complaintTypeId',// name of the key we're adding 
        {   
           type: Sequelize.INTEGER,
           references: {
             model: 'ComplaintTypes', // name of Target model 
             key: 'id', // key in Target model that we're referencing
                   
              }
            }
          );
        })
       .then(() => {
        // complain has one feedback
        return queryInterface.addColumn(
          'Feedback', // name of Target model
          'complainId', // name of the key we're adding
          {
            type: Sequelize.INTEGER,
            references: {
              model: 'Complain', // name of Source model
              key: 'id',
           }
         }
        );
      })
        .then(() => {
        // complain belongs to status
        return queryInterface.addColumn(
        'Complain', // name of Source model
          'statusId',// name of the key we're adding 
           {
            type: Sequelize.INTEGER,
            references: {
              model: 'Status', // name of Target model
              key: 'id', // key in Target model that we're referencing
            }
          }
        );
      });
    },
  down: (queryInterface, Sequelize) => {
  
  }
};