'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('ComplaintTypes', [{
      id: 1,
      typeName: 'Water'
    },{
      id: 2,
      typeName: 'Sewerage'
    },{
      id: 3,
      typeName: 'load'
    }], {});
  },

  down: (queryInterface, Sequelize) => {
  
  }
};
