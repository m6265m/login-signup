'use strict';

module.exports = {
  up: (queryInterface, Sequelize) => {
    return queryInterface.bulkInsert('Status', [{
      id: 1,
      statusType: 'Resolved'
    },{
      id: 2,
      statusType: 'Unresolved'
    },{
      id: 3,
      statusType: 'Assgined'
    }], {});
  },

  down: (queryInterface, Sequelize) => {
   
  }
};
