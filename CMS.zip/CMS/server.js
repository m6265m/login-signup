
var express = require('express');
app  = express();
var bodyParser = require('body-parser');

app.use(bodyParser.json({ type: '*/*' } ));
 
app.use(bodyParser.urlencoded({ extended: false}));
require('./router/router.js')(app);

var server = app.listen(3000, function () {
         console.log("Site is live");
    })
    app.get('/', function(req, res) {
     
     res.send('Welcome to Passport with Sequelize');
       
      });
     