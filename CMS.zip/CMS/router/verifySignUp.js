
var bcrypt = require('bcryptjs');
 const db =require('../models');
 const User=db.User;
exports.checkDuplicateCnicOrEmail = (req, res, next) => {
  // -> Check cnic is already in use
  User.findAll(
    {
      attributes:['cnic']
    }).then(user => {
  
   var checkCnic=0;
    for(var i=0;i<user.length;i++){
     
      checkCnic = bcrypt.compareSync(req.body.cnic, user[i].cnic);
      if(checkCnic){
        res.status(400).send("Fail -> cnic is already in use!");
        return;
       }
  }
    // -> Check Email is already in use
    User.findOne({ 
      where: {
        email: req.body.email
      } 
    })
    .then(user => {
      if(user){
        res.status(400).send("Fail -> Email is already in use!");
        return;
      }
        
      next();
    });
  });
}
