'use strict';
module.exports = (sequelize, DataTypes) => {
  const Location = sequelize.define('Location', {

  latitude: DataTypes.FLOAT,
    longitude: DataTypes.FLOAT,
  },{  freezeTableName: true,});
  Location.associate = function(models) {
    // associations can be defined here
    this.hasOne(models.Complain);
  };
  return Location;
};