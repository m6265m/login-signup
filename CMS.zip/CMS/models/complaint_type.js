'use strict';
module.exports = (sequelize, DataTypes) => {
  const ComplaintTypes= sequelize.define('ComplaintTypes', {
   
    typeName: DataTypes.STRING
  },{  freezeTableName: true,});

  ComplaintTypes.associate = function(models) {
    // associations 
   this.hasOne(models.Complain);
  };
  return ComplaintTypes;
};