'use strict';
module.exports = (sequelize, DataTypes) => {
  const Feedback = sequelize.define('Feedback', {
 
    description: DataTypes.STRING,
 
    createdAt: DataTypes.DATE

  },{  freezeTableName: true,});
  Feedback.associate = function(models) {
  
   this.belongsTo(models.Complain);
   
  };
  return Feedback;
};