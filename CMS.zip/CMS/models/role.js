'use strict';
module.exports = (sequelize, DataTypes) => {
  const Roles = sequelize.define('Roles', {
   
    name: {
      type: DataTypes.STRING
    }
   
  },{  freezeTableName: true,});
  
  Roles.associate = function(models) {
      // // associations can be defined here
      this.belongsToMany(models.User, { through: 'user_roles', foreignKey: 'roleId', otherKey: 'userd'}); 
    };
   
  
  return Roles;
}