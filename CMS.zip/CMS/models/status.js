'use strict';
module.exports = (sequelize, DataTypes) => {
  const Status = sequelize.define('Status', {
   
    statusType: DataTypes.STRING
  },{  freezeTableName: true,});
  Status.associate = function(models) {
 
  };
  return Status;
};