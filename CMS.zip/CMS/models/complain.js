'use strict';
module.exports = (sequelize, DataTypes) => {
  const Complain = sequelize.define('Complain', {
 
    noOfRequests:DataTypes.INTEGER,

    description: DataTypes.STRING,

    image: DataTypes.STRING,

  },{  freezeTableName: true,});
  Complain.associate = function(models) {
    // associations
    this.belongsTo(models.User);
    this.belongsTo(models.Location);
    this.belongsTo(models.Status);
    this.belongsTo(models.ComplaintTypes);
    this.hasOne(models.Feedback);
  };
 
  return Complain;
};