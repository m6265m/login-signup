'use strict';
module.exports = (sequelize, DataTypes) => {
    const User = sequelize.define('User', {
      name: {
        type: DataTypes.STRING
      },
      username: {
        type: DataTypes.STRING
      },
      email: {
        type: DataTypes.STRING
      },
      password: {
        type: DataTypes.STRING
      },
      phoneNumber: {
        type: DataTypes.STRING
      },
      cnic: {
        type: DataTypes.STRING
      },
      updatedAt: DataTypes.DATE,
      createdAt: DataTypes.DATE
    },{  freezeTableName: true,});
    User.associate = function(models) {
        // // associations can be defined here
        this.belongsToMany(models.Roles, { through: 'user_roles', foreignKey: 'userId', otherKey: 'roleId'});
       this.hasMany(models.Complain);
   
      
      };
     

    return User;
  }
  